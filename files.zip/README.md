# Ondřej Opočenský — Personal & Business Card

Osobní vizitka s Three.js 3D efekty, custom kurzorem a scroll animacemi.

## Struktura souborů

```
index.html          ← hlavní stránka
img/
  profile.jpg       ← profilová fotka (Alps selfie)
  photo_1_alps.png
  photo_2_alps2.png
  photo_3_ski.png
  photo_4_sea.png
  photo_5_skydive.png
  photo_6_dino.png
  photo_7_lidl_run.png
  photo_8_waterfall.png
  photo_9_waterfall2.png
  photo_10_climbing.png
  photo_11_climbing2.png
```

## Jak spustit lokálně

Otevři `index.html` přímo v prohlížeči. Fotka se načte z `img/profile.jpg`.

## GitHub Pages (živý web zdarma)

1. Nahraj všechny soubory na GitHub
2. Jdi do **Settings → Pages**
3. Source: **Deploy from a branch → main → / (root)**
4. Za chvíli bude web živý na `https://tvuj-username.github.io/nazev-repo`
